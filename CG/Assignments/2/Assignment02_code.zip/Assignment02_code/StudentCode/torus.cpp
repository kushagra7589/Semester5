#include <glad/glad.h>
#include <vector>
#include <glm/gtc/constants.hpp>

//TODO:create and draw torus here
//refer cube.cpp for example
void createTorusObject(GLuint &torusVAO){


}

void drawTorus(GLuint &torusVAO,GLuint program){


}
