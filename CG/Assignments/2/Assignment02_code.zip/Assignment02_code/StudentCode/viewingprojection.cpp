#include <glad/glad.h>
#include <glm/gtc/type_ptr.hpp>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include "tvp.hpp"


//TODO implement this functions for part 2
glm::mat4 myLookAt(const glm::vec3 eye, const glm::vec3 center, const glm::vec3 up)
{
    //TODO:your look at definition
    return glm::mat4();
}

glm::mat4 getViewMatrix(){

    //TODO call your lookAt function here

    //Camera at (0, 0, 100) looking down the negative Z-axis in a right handed coordinate system
    return  glm::lookAt(glm::vec3(0.0,0.0,100.0), glm::vec3(0.0, 0.0, 0.0), glm::vec3(0.0, 1.0, 0.0));
}


//TODO change projection matrix here
glm::mat4 getProjectionMatrix(float aspect, float height, float width) {
    float view_height = 100.0f;
    glm::mat4 projection = glm::ortho(-view_height*aspect/2.0f, view_height*aspect/2.0f, -view_height/2.0f, view_height/2.0f, 0.1f, 1000.0f);

    return projection;
}
