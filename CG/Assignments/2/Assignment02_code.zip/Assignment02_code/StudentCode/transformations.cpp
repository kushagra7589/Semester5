
#include <glad/glad.h>
#include <glm/gtc/type_ptr.hpp>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

//TODO implement these functions for part 1
glm::mat4 rotateAroundZ(){

    return glm::mat4(1.0);

}
glm::mat4 scaleAlongY(){

    return glm::mat4(1.0);

}
glm::mat4 translateAlongXY(){

    return glm::mat4(1.0);

}

glm::mat4 composeOrder1(){

    return glm::mat4(1.0);

}
glm::mat4 composeOrder2(){

    return glm::mat4(1.0);

}


glm::mat4 getModelMatrix()
{
    //Modelling transformations (Model -> World coordinates)
    glm::mat4 model = glm::mat4(1.0);

    //TODO: use the above functions here
    //    model = rotateAroundZ();
    //    model = scaleAlongY();
    //    model = translateAlongXY();
    //    model = composeOrder1();
    //    model = composeOrder2();

    return model;

}
