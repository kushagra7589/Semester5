#ifndef _SHADER_UTILS_H_
#define _SHADER_UTILS_H_


#include <glad/glad.h>

GLuint createProgram(const char *vshader_filename, const char* fshader_filename);

#endif
