/// @ref core
/// @file glm/packing.hpp

#pragma once

#include "detail/func_packing.hpp"
