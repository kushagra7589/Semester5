#include "src/Game.hpp"


int main(int argc, char ** argv) {


    Game g(800, 600,"Pong");
    g.run();

    return 0;

}