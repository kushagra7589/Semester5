import numpy as np


# make sure this class id compatable with sklearn's LogisticRegression

class LogisticRegression(object):

	def __init__(self, penalty='l2' , C=1.0 , max_iter=100 , verbose=0):
		# define all the model weights and state here
		pass

	def fit(X , Y):
		pass

	def predict(X ):
		pass 
		# return a numpy array of predictions
