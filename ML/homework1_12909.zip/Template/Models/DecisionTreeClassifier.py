import numpy as np


# make sure this class id compatable with sklearn's DecisionTreeClassifier

class DecisionTreeClassifier(object):

	def __init__(self, max_depth=None, min_samples_split=2, min_samples_leaf=1, max_features=None):
		# define all the model weights and state here
		pass

	def fit(X , Y):
		pass

	def predict(X ):
		pass 
		# return a numpy array of predictions
