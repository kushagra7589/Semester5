import numpy as np


# make sure this class id compatable with sklearn's GaussianNB

class GaussianNB(object):

	def __init__(self ):
		# define all the model weights and state here
		pass

	def fit(X , Y):
		pass

	def predict(X ):
		pass 
		# return a numpy array of predictions